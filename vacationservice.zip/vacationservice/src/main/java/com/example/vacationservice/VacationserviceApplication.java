package com.example.vacationservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VacationserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(VacationserviceApplication.class, args);
	}

}
